# coding=utf-8
from pyquery import PyQuery as pq
import ConfigParser
import requests
import os
import chardet


def fetch_ppt(course_name, course_url):
    # 访问爬取网站, 提取文档网址, 保存至urls {filename : url}
    urls = {}
    header = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36',
        'Cookie': 'JSESSIONID=28422717-9d2b-48f4-8443-d7f1287cfb36.couser; CASTGC=TGT-233599-fsHBCd9IGxTCohSr9pnkbf7uLdEMw6aednmZ0UvXMhWYyzWtMb-cas'
    }
    req = requests.request(method='GET', url=course_url, headers=header)
    p = pq(req.text)
    a_s = p('.dataGrid').eq(0).find('a')
    for i in range(len(a_s)):
        url = a_s.eq(i).attr('href')
        filename = a_s.eq(i).text().encode("utf-8")
        urls[filename] = url
        # print filename, url
        # print type(filename), type(url)
        # print chardet.detect(url)
        # print chardet.detect(filename)

    # 数据保存
    os.makedirs(course_name)
    course_name = course_name.decode("gbk")
    # print chardet.detect(course_name)
    for pdf_name in urls:
        uni_pdf_name = pdf_name.decode("utf-8")
        print 'Downloading ', pdf_name, '...'
        with open(os.path.join(course_name, uni_pdf_name), 'wb') as fout:
            data = requests.get(url=urls[pdf_name], headers=header).content
            fout.write(data)


if __name__ == '__main__':
    # 解析配置文件
    config_file = 'config.txt'
    cf = ConfigParser.ConfigParser()
    cf.read(config_file)
    # print cf.sections()
    # print cf.options('course_info')
    # print cf.get('course_info', 'course_name').decode('gbk')

    stu_id = cf.get('student_info', 'id')
    stu_pw = cf.get('student_info', 'password')
    course_number = cf.getint('course_info', 'course_number')
    for i in range(1, course_number + 1, 1):
        course_name = cf.get('course_info', 'course_name'+str(i))
        course_url = cf.get('course_info', 'course_url'+str(i))
        fetch_ppt(course_name, course_url)
        # print stu_id, stu_pw, course_number, course_name, course_url
